package com.game.src.main;
import com.game.src.main.Game.STATE;
import com.game.src.main.Game.PLAYER_STATE;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFrame;

import com.game.src.main.states.Menu;
import com.game.src.main.states.Outside;
import com.game.src.main.states.TukosRoom;



public class Game extends Canvas implements Runnable{
	
	
	private static final long serialVersionUID = 1L;
	public static final int WIDTH = 640;
	public static final int HEIGHT = 512;
	public static final int SCALE = 2;
	public final String TITLE = "Chicken Fiesta";
	
	
	private boolean running = false;
	private Thread thread; //loads multiple methods at the same time
	
	//Image variables
	private BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
	private BufferedImage tuko = null;
	private BufferedImage tukoL = null;
	private BufferedImage tukoR = null;
	private BufferedImage tukoRoom = null;
	private BufferedImage spriteSheet = null;
	private BufferedImage chicken = null;
	private BufferedImage outsideRoom = null;
	private BufferedImage egg = null;
	
	
	//Objects
	private Textures textures;
	private Entity player; 
	private TukosRoom tk;
	private Menu menu;
	private Entity_Movement controller;
	private Outside outside;
	
	
	//Lists
	private ArrayList<Entity> chickens; //super class reference
	private ArrayList<Player> players; //sub class reference
	private ArrayList<Entity> eggs;
	
	//in order to make menu screens/levels you need to make different states of the game
	//The states are called "enumerations"
	
	public enum STATE{ MENU, GAME, OUTSIDE }	public enum PLAYER_STATE{ LEFT, RIGHT, FORWARD}	public static PLAYER_STATE pState = PLAYER_STATE.FORWARD;
	public static STATE state = STATE.MENU;
	
	
	
	public void init()
	{
		requestFocus(); //forces you to interact with screen
		BufferedImageLoader loader = new BufferedImageLoader();
		
		try {
			
			tuko = loader.loadImage("/res/Tuko.png");
			tukoL = loader.loadImage("/res/TukoLeft48.png");
			tukoR = loader.loadImage("/res/TukoRight48.png");
			tukoRoom = loader.loadImage("/res/TukoRoom400.png");
			spriteSheet = loader.loadImage("/res/atlas_48x.png");
			chicken = loader.loadImage("/res/Chicken.png");
			outsideRoom = loader.loadImage("/res/Outside400.png");
			egg = loader.loadImage("/res/egg.png");
		}catch(IOException e){
			e.printStackTrace();
		}
		
		
		addKeyListener(new KeyInput(this));
		this.addMouseListener(new MouseInput());
		
		
		textures = new Textures(this);
		controller = new Entity_Movement(textures, this);
		player = new Player(200, 200, textures, controller); //upcasting (entity object)
		tk = new TukosRoom(player, textures);
		
		menu = new Menu();	
		outside = new Outside(textures, player);
		
		controller.createEntity(5);
		chickens = controller.getChickenList();
		players = controller.getPlayerList();
		eggs = controller.getEggList();
	}
	
	
	
	///////////////
	//SYNCHRONIZED START AND STOP METHODS
	///////////////
	
	
	private synchronized void start()
	{
		if(running)//makes sure the game isn't running
			return;
		
		running = true;
		
		Thread thread = new Thread(this); //starts threads
		thread.start();
	}
	private synchronized void stop() //synchronized accesses multiple threads at the same time
	{
		if(!running) //makes sure game isn't already stopped
			return;
		
		running = false;
		
		try {
			thread.join();//joining the threads together could possibly fail, which is why we need to catch exceptions
		}
		catch(InterruptedException e) {
			e.printStackTrace();//prints error message
		}
		System.exit(1);
	}
	
	
	//////////////////
	//RUN METHODS
	/////////////////
	
	
	
	public void run() {
		init();
		long lastTime = System.nanoTime();
		final double amountOfTicks = 60.0;
		double ns = 1000000000/amountOfTicks;
		double delta = 0;
		int updates = 0;
		int frames = 0;
		long timer = System.currentTimeMillis();
		
		
		
		while(running)
		{
			//the game loop
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			if(delta >= 1)
			{
				tick();
				updates++;
				delta--;
			}
			render();
			frames++;
			
			if(System.currentTimeMillis() - timer > 1000 )
			{
				timer += 1000;
				System.out.println(updates + " Ticks " + frames + "Fps");
				updates = 0;
				frames = 0;
			}
		}
		stop();
	}
	
	private void tick()
	{
		
		if(!(state == STATE.MENU))
		{
		player.tick();
		controller.tick();
		}
	}
	
	///////
	//RENDER IMAGES
	///////
	

	
	private void render()
	{
		BufferStrategy bs = this.getBufferStrategy();
		//"this" refers to canvas class because it is extended
		
		if(bs == null)
		{
			createBufferStrategy(3);//triple buffering increases load speed
			return;
		}
		
		Graphics g = bs.getDrawGraphics();
		//////////////////
		g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
		
		
		if(state == STATE.GAME)
		{
			
			tk.renderRoom(g);
			tk.setPlayerBounds();
			if(pState == PLAYER_STATE.FORWARD)
				player.render(g);
			else if(pState == PLAYER_STATE.LEFT)
				player.render(g);
			else if(pState == PLAYER_STATE.RIGHT)
				player.render(g);
			controller.render(g);
			tk.render(g);
			
			
		}
		else if(state == STATE.OUTSIDE)
		{
			outside.render(g);
			if(pState == PLAYER_STATE.FORWARD)
				player.render(g);
			else if(pState == PLAYER_STATE.LEFT)
				player.render(g);
			else if(pState == PLAYER_STATE.RIGHT)
				player.render(g);
			controller.render(g);
		}
		else if(state == STATE.MENU)
		{
			menu.render(g);
		}
		//////////////////
		g.dispose();//must remove bufferstrategy 
		bs.show();
	}
	
	
	///////////////
	//controls
	/////////////////
	
	
	
	public void keyPressed(KeyEvent e)
	{
		if(!(state == STATE.MENU)) //Downcasting entity object to player
		((Player)player).keyPressed(e);
	}
	public void keyReleased(KeyEvent e)
	{
		if(!(state == STATE.MENU))
		((Player)player).keyReleased(e);
	}
	
	public void mousePressed(MouseEvent e)
	{
		if(!(state == STATE.MENU))
		{
			MouseInput x = new MouseInput();
			x.mousePressed(e);
		}
	}
	
	
	/////////////
	//main method
	//////////////
	
	
	
	public static void main(String[] args)
	{
		Game game = new Game();
		
		game.setPreferredSize(new Dimension(WIDTH , HEIGHT )); //sets screen size
		game.setMaximumSize(new Dimension(WIDTH, HEIGHT ));
		game.setMinimumSize(new Dimension(WIDTH , HEIGHT ));
		
		JFrame frame = new JFrame(game.TITLE);
		frame.add(game);
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		
		game.start();
	}
	
	
	
	
	//Accessor methods
	public BufferedImage getTuko()
	{
		return tuko;
	}
	public BufferedImage getTukoLeft()
	{
		return tukoL;
	}
	public BufferedImage getTukoRight()
	{
		return tukoR;
	}
	public Entity getPlayer()
	{
		return player;
	}
	public BufferedImage getTukosRoom()
	{
		return tukoRoom;
	}
	public BufferedImage getSpriteSheet()
	{
		return spriteSheet;
	}
	public ArrayList<Entity> getChickens()
	{
		return chickens;
	}
	public ArrayList<Player> getPlayers()
	{
		return players;
	}
	public BufferedImage getChicken()
	{
		return chicken;
	}
	public BufferedImage getOutside()
	{
		return outsideRoom;
	}
	public ArrayList<Entity> getEggs()
	{
		return eggs;
	}
	public BufferedImage getEgg()
	{
		return egg;
	}
	

}
