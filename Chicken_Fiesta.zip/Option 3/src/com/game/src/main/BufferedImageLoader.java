package com.game.src.main;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;

public class BufferedImageLoader {
	private BufferedImage image;
	
	public BufferedImage loadImage(String path) throws IOException
	{
		
		image = ImageIO.read(getClass().getResource(path));
		return image;
	}
}
//first big error encountered
/*
 * Java 17 changed the getclass and getresource methods
 * They no longer automatically look through the entire "option 3" folder
 * Just where SRC is located, therefore you need to both specify the path in main and place "resource"
 * as a package in SRC folder
 */
