package com.game.src.main;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

import com.game.src.main.Game.PLAYER_STATE;
import com.game.src.main.Game.STATE;

public class Player extends Entity{
	
	private Textures textures;
	private BufferedImage state;
	
	
	private double velX = 0;
	private double velY = 0; 
	private Entity_Movement controller;

	public Player(double x, double y, Textures textures, Entity_Movement controller)
	{
		super(x, y, textures);
		this.textures = textures;
		state = textures.getPlayer();
		this.controller = controller;

	
		
	}
		public void keyPressed(KeyEvent e)//Pressing KeyBoard Buttons
		{
			int key = e.getKeyCode();
			
			if(key == KeyEvent.VK_D) 
			{
				setVelX(3);
				Game.pState = PLAYER_STATE.RIGHT;
				state = textures.getPlayerRight();
				
			}
				else if(key == KeyEvent.VK_A) 
				{
					setVelX(-3);
					Game.pState = PLAYER_STATE.LEFT;
					state = textures.getPlayerLeft();
				}
				else if(key == KeyEvent.VK_S) 
				{
					setVelY(3);
					Game.pState = PLAYER_STATE.FORWARD;
					state = textures.getPlayer();
				}
				else if(key == KeyEvent.VK_W) 
				{
					setVelY(-3);
					Game.pState = PLAYER_STATE.FORWARD;
					state = textures.getPlayer();
				}
				else if(key == KeyEvent.VK_SPACE)
				{
					controller.addEgg(new Egg(getX(), getY(), textures, controller));
				}
			
		}
		
		public void keyReleased(KeyEvent e) //Releasing Keyboard buttons
		{
	int key = e.getKeyCode();
			
			if(key == KeyEvent.VK_D) 
			{
				this.setVelX(0);
				Game.pState = PLAYER_STATE.FORWARD;
				state = textures.getPlayer();
			}
				else if(key == KeyEvent.VK_A) 
				{
					this.setVelX(0);
					Game.pState = PLAYER_STATE.FORWARD;
					state = textures.getPlayer();
					
				}
				else if(key == KeyEvent.VK_S) 
				{
					this.setVelY(0);
					Game.pState = PLAYER_STATE.FORWARD;
					state = textures.getPlayer();
				}
				else if(key == KeyEvent.VK_W) 
				{
					this.setVelY(0);
					Game.pState = PLAYER_STATE.FORWARD;
					state = textures.getPlayer();
				}
		
	}
		@Override
		public void tick() {
			
			setX(getX() + velX);
			setY(getY() + velY);
			
	
			if(getX() <= getXZeroBound()) //forces the player to stay within area
				setX(getXZeroBound());
			if(getX() >= getXPlayerBound())
				setX(getXPlayerBound());
			if(getY() <= getYZeroBound())
				setY(getYZeroBound());
			if(getY() >= getYPlayerBound())
				setY(getYPlayerBound());
			
			
			if(getX() >= 140 && getX() <= 180)//Door mechanic
			{
				if(getY() >= 320 && getY() <= 400)
					Game.state = STATE.OUTSIDE; 
			}
	
		}
		@Override
		void render(Graphics g) {
			g.drawImage(state, (int)getX(), (int)getY(), null);
			
		}
		
		
		public Rectangle getBounds() //hitbox
		{
			return new Rectangle((int)getX(), (int)getY(), 32 ,32);
		}
		
		
		
		
		
		public double getVelX()
		{
			return velX;
		}
		
		public double getVelY()
		{
			return velY;
		}
		
		public void setVelX(double velX)
		{
			this.velX = velX;
		}
		
		public void setVelY(double velY)
		{
			this.velY = velY;
		}
		
		public String toString()
		{
			return(super.toString() + " Velocity (x, y): " + velX + " " + velY);
		}
}
