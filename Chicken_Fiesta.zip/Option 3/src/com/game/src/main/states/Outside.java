package com.game.src.main.states;

import java.awt.Graphics;

import com.game.src.main.Entity;
import com.game.src.main.Textures;

public class Outside {
	Textures textures;
	Entity entity;
	public Outside(Textures textures, Entity entity)
	{
		this.textures = textures;
		this.entity = entity;
	}
	
	public void render(Graphics g)
	{
		g.drawImage(textures.getOutside(), 120, 50, null);
	}
}
