package com.game.src.main.states;

import java.awt.Graphics;

import com.game.src.main.Entity;
import com.game.src.main.Textures;

public class TukosRoom {
	Textures textures;
	Entity entity;
	
	
	public TukosRoom(Entity entity, Textures textures)
	{
		this.entity = entity;
		this.textures = textures;
	}
	
	public void renderRoom(Graphics g)
	{
		g.drawImage(textures.getTukosRoom(), 120, 50, null);
		
	}
	public void render(Graphics g)
	{
		g.drawImage(textures.getDoor(), 120, 380, null);
	}
	
	public void setPlayerBounds()
	{
		entity.setXPlayerBound(465);
		entity.setYPlayerBound(370);
		entity.setXZeroBound(110);
		entity.setYZeroBound(100);
	}
}
