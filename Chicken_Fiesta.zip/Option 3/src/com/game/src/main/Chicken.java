package com.game.src.main;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;

public class Chicken extends Entity{
	

	private Textures textures;
	private Random r = new Random();
	private int ticks;
	private Game game;
	private Entity_Movement controller;
	
	
	public Chicken(double x, double y, Textures textures,  Game game, Entity_Movement controller)
	{
		super(x, y, textures);
		this.textures = textures;
		ticks = 0;
		this.game = game;
		this.controller = controller;
		
	}

	@Override
	public void tick() {
		
		setY(ticks++);
		//ticks++;
		
		if(getY() > 400)
		{
			setY(r.nextInt(200) + 100);
			setX(r.nextInt(280) + 150);
			ticks = 100;
		}
		
		if(Physics.Collision(this, game.getEggs()))
		{
	
			ticks = r.nextInt(200) + 100;
			setX(r.nextInt(335) + 150);
			
			controller.removeChicken(this);
			//controller.addChicken(this);
			controller.createEntity(1);
		}
	}
	
	
	@Override
	public void render(Graphics g) {
		g.drawImage(textures.getChicken(), (int)getX(), (int)getY(), null);
		
	}
	
	
	public void setBounds()
	{
		this.setXPlayerBound(465);
		this.setYPlayerBound(370);
		this.setXZeroBound(110);
		this.setYZeroBound(100);
	}
	public Rectangle getBounds()
	{
		return new Rectangle((int)getX(), (int)getY(), 48, 48);
	}
	
	
	public String toString()
	{
		return(super.toString() + " ticks: " + ticks);
	}
	
	
}
