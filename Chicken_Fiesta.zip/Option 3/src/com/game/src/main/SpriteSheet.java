package com.game.src.main;

import java.awt.image.BufferedImage;

public class SpriteSheet {

	private BufferedImage image;
	
	public SpriteSheet(BufferedImage image)
	{
		this.image = image; //takes from spritesheet image and takes individual images
	}
	
	
	public BufferedImage grabSubImage(int col, int row, int width, int height )
	{
		BufferedImage img = this.image.getSubimage((col * 32)-32, (row * 32)-32, width, height);
		return img;
	}
	
	
	//grabImage(1, 1, 32, 32)
}
