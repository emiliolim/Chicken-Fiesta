package com.game.src.main;

import java.awt.Graphics;
import java.awt.Rectangle;

public abstract class Entity {
	
	
	private double x;
	private double y;
	
	private int xPlayerBound;
	private int yPlayerBound;
	private int xZeroBound;
	private int yZeroBound;
	private Textures textures;
	
	
	
	abstract void render(Graphics g);
	
	
	
	public Entity(Textures textures)
	{
		this.x = 100;
		this.y = 100;
		this.textures = textures;
		xPlayerBound = 540; //sets boundary that player can move in the screen
		yPlayerBound = 420;
		xZeroBound = 0;
		yZeroBound = 0;
	}
	public Entity(double x, double y,Textures textures)
	{
		this.x = x;
		this.y = y;
		xPlayerBound = 540; 
		yPlayerBound = 420;
		xZeroBound = 0;
		yZeroBound = 0;
		this.textures = textures;
		

	}
	

	public void tick()
	{
		if(getX() <= getXZeroBound()) //forces the player to stay within area
			setX(getXZeroBound());
		if(getX() >= getXPlayerBound())
			setX(getXPlayerBound());
		if(getY() <= getYZeroBound())
			setY(getYZeroBound());
		if(getY() >= getYPlayerBound())
			setY(getYPlayerBound());
		
	}
	
	public Rectangle getBounds()
	{
		return new Rectangle((int)x, (int)y, 32, 32);
	}
	

	
	public double getX()
	{
		return x;
	}
	
	public double getY()
	{
		return y;
	}
	
	public void setX(double x)
	{
		this.x = x;
	}
	
	public void setY(double y)
	{
		this.y = y;
	}
	
	
	
	
	public int getXPlayerBound()
	{
		return xPlayerBound;
	}
	
	public int getYPlayerBound()
	{
		return yPlayerBound;
	}
	
	public void setXPlayerBound(int xPlayerBound)
	{
		this.xPlayerBound = xPlayerBound;
	}
	
	public void setYPlayerBound(int yPlayerBound)
	{
		this.yPlayerBound = yPlayerBound;
	}
	
	public int getXZeroBound()
	{
		return xZeroBound;
	}
	
	public int getYZeroBound()
	{
		return yZeroBound;
	}
	
	public void setXZeroBound(int xZeroBound)
	{
		this.xZeroBound = xZeroBound;
	}
	
	public void setYZeroBound(int yZeroBound)
	{
		this.yZeroBound = yZeroBound;
	}
	
	public Textures getTextures()
	{
		return textures;
	}
	
	public String toString()
	{
		return("X/Y Coords: " + x + ", " + y + " X/Y Boundary (Right and Bottom Screen): " + xPlayerBound + ", " + yPlayerBound + " X/Y Boundary (Top and Left Screen): " + xZeroBound + ", " + yZeroBound );
	}
	
	
}
