package com.game.src.main;

import java.awt.image.BufferedImage;

public class Textures {

	private SpriteSheet ss;
	private SpriteSheet tk, tk_left, tk_right;
	private SpriteSheet d;
	private SpriteSheet chickenSS, eggSS;
	private SpriteSheet o;
	private BufferedImage player, tukosRoom, door, playerLeft, playerRight, chicken, egg, outside;
	
	
	
	public Textures(Game game)
	{
		ss = new SpriteSheet(game.getTuko());
		tk = new SpriteSheet(game.getTukosRoom());
		tk_left = new SpriteSheet(game.getTukoLeft());
		tk_right = new SpriteSheet(game.getTukoRight());
		d = new SpriteSheet(game.getSpriteSheet());
		chickenSS = new SpriteSheet(game.getChicken());
		o = new SpriteSheet(game.getOutside());
		eggSS = new SpriteSheet(game.getEgg());
		getTextures();
	}
	
	public void getTextures() {
		player = ss.grabSubImage(1,1, 64 ,64);
		playerLeft = tk_left.grabSubImage(1, 1, 64, 64);
		playerRight = tk_right.grabSubImage(1, 1, 64, 64);
		tukosRoom = tk.grabSubImage(1,1,400,400);
		door = d.grabSubImage(37, 6, 96, 70);
		chicken = chickenSS.grabSubImage(1, 1, 64, 64);
		outside = o.grabSubImage(1, 1, 400, 400);
		egg = eggSS.grabSubImage(1,1,64,64);
	}
	
	public BufferedImage getPlayer()
	{
		return player;
	}
	public BufferedImage getTukosRoom() 
	{
		return tukosRoom;
	}
	public BufferedImage getDoor()
	{
		return door;
	}
	public BufferedImage getPlayerLeft()
	{
		return playerLeft;
	}
	public BufferedImage getPlayerRight()
	{
		return playerRight;
	}
	public BufferedImage getChicken()
	{
		return chicken;
	}
	public BufferedImage getOutside()
	{
		return outside;
	}
	public BufferedImage getEgg()
	{
		return egg;
	}
}
