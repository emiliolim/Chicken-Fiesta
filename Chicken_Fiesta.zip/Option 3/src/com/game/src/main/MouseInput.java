package com.game.src.main;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class MouseInput implements MouseListener{

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	public void mousePressed(MouseEvent e) {
		
		int mouseX = e.getX();
		int mouseY = e.getY();
		/*
		 * public Rectangle playButton = new Rectangle(Game.WIDTH/4 + 120, 150, 100, 50);
		   public Rectangle helpButton = new Rectangle(Game.WIDTH/4 + 120, 250, 100, 50);
		   public Rectangle quitButton = new Rectangle(Game.WIDTH/4 + 120, 350, 100, 50);
		 */
		
		
		//Play Button
		if(mouseX >= Game.WIDTH / 4 + 120 && mouseX <= Game.WIDTH / 4 + 220 )
		{
			if(mouseY >= 150 && mouseY <= 200)
			{
				//Pressed Play Button
				Game.state = Game.STATE.GAME;
			}
			
			if(mouseY >= 350 && mouseY <= 400)
			{
				//Quit button
				System.exit(1);
			}
		}
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}



	
	
}
