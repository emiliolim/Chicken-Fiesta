package com.game.src.main;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;

public class Entity_Movement {

	private ArrayList<Entity> c = new ArrayList<Entity>();
	private ArrayList<Player> e = new ArrayList<Player>();
	private ArrayList<Entity> eggs = new ArrayList<Entity>();
	
	private Egg tempEgg;
	private Chicken tempChicken;
	private Textures textures;
	private Game game;
	private Random r = new Random();
	
	
	
	public Entity_Movement(Textures textures, Game game) 
	{
		this.textures = textures;
		this.game = game;
		
	}
	
	public void createEntity(int num)
	{
		
		for(int i = 0; i < num; i++)
		{
			addChicken(new Chicken(r.nextInt(265)+ 110, r.nextInt(300) + 200, textures, game, this));
			
		}
	}
	public void tick()
	{
		for(int i = 0; i < c.size(); i++ )
		{
			tempChicken = (Chicken)c.get(i);
			
			tempChicken.tick();
		}
		for(int i = 0; i < eggs.size(); i++ )
		{
			tempEgg = (Egg)eggs.get(i);
			
			tempEgg.tick();
		}
	}
	
	public void render(Graphics g)
	{
		for(int i = 0; i < c.size(); i++)
		{
			tempChicken = (Chicken)c.get(i);
			tempChicken.render(g);
		}
		for(int i = 0; i < eggs.size(); i++)
		{
			tempEgg = (Egg)eggs.get(i);
			tempEgg.render(g);
		}
	}
	
	
	public void addEgg(Egg block)
	{
		eggs.add(block);
	}
	
	public void removeEgg(Egg block)
	{
		eggs.remove(block);
	}
	
	public void addChicken(Chicken block)
	{
		c.add(block);
	}
	
	public void removeChicken(Chicken block)
	{
		c.remove(block);
	}
	
	public ArrayList<Entity> getChickenList()
	{
		return c;
	}
	public ArrayList<Player> getPlayerList()
	{
		return e;
	}
	public ArrayList<Entity> getEggList()
	{
		return eggs;
	}
	public Chicken getChicken()
	{
		return tempChicken;
	}
	
}
