package com.game.src.main;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.lang.ModuleLayer.Controller;

public class Egg extends Entity{

	private Textures textures;
	private double x, y;
	private Entity_Movement controller;
	
	public Egg(double x, double y, Textures textures, Entity_Movement controller) {
		super(x, y, textures);
		this.textures = textures;
		this.x = x;
		this.y = y;
		this.controller = controller;
	}

	@Override
	public void tick() {
		y-= 3;
		
		if(y <= 0)
		{
			controller.removeEgg(this);
		}
	}

	@Override
	void render(Graphics g) {
		g.drawImage(textures.getEgg(), (int)x, (int)y, null);
		
	}
	
	public Rectangle getBounds()
	{
		return new Rectangle((int)getX(), (int)getY(), 48 , 48);
	}
	

	
	

}
