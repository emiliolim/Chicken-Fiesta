package com.game.src.main;

import java.util.ArrayList;

public class Physics {

	public static boolean Collision(Entity go, ArrayList<Chicken> chickens )
	{
		for(int i = 0; i < chickens.size(); i++)
		{
			if(go.getBounds().intersects(chickens.get(i).getBounds()))
				return true;
		}
		return false;
	}
	
	public static boolean Collision(Chicken chicken, Entity go)
	{
		
			if(chicken.getBounds().intersects(go.getBounds()))
			{
				return true;
			}
		return false;
	}
	
	public static boolean Collision(Chicken chicken, ArrayList<Entity> eggs)
	{
		for(int i = 0; i < eggs.size(); i++)
		{
			if(chicken.getBounds().intersects(eggs.get(i).getBounds()))
			{
				return true;
			}
		}
		return false;
	}

}
